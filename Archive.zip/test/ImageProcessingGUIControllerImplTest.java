import org.junit.Before;

import java.io.StringReader;

import controller.ImageProcessingController;
import controller.ImageProcessingControllerImpl;
import controller.ImageProcessingGUIController;
import controller.ImageProcessingGUIControllerImpl;
import model.GUIProcessingModel;
import model.GUIProcessingModelImpl;
import view.GUIView;
import view.IGUIView;
import view.ImageProcessingView;
import view.ImageProcessingViewImpl;

/**
 * the test class for main GUI controller
 */
public class ImageProcessingGUIControllerImplTest {
  private ImageProcessingGUIController main;
  private ImageProcessingController delegate;
  private GUIProcessingModel model;
  private IGUIView view;
  private ImageProcessingView delegateView;

  @Before
  public void initialize() {
    this.model = new GUIProcessingModelImpl();
    this.delegateView = new ImageProcessingViewImpl();
    this.view = new GUIView();
    this.delegate = new ImageProcessingControllerImpl(
            model, delegateView, new StringReader("load res/test/square.png square"));
    this.main = new ImageProcessingGUIControllerImpl(model);
  }

  /*
  can't really test controller itself. Since we are using delegate and model,
  we can assume the features are tested through model testing and our original controller
  testings.
   */
}